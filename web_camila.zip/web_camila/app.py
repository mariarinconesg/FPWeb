from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def inicio():
    return render_template('index.html')

@app.route('/sobre-mi')
def sobre_mi():
    return render_template('sobre-mi.html')

@app.route('/portafolio')
def portafolio():
    return render_template('portafolio.html')

@app.route('/contacto')
def contacto():
    return render_template('contacto.html')

@app.route('/hoja-de-vida')
def hoja_de_vida():
    return render_template('hoja-de-vida.html')

if __name__ == '__main__':
    app.run(debug=True)
