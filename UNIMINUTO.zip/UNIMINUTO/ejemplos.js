//manejo de selectores
const titulo=document.querySelector("h1");
titulo.textContent="Llegamos a JS";
const titulo2=document.querySelector("h2");
titulo2.textContent="Mikaa";
//manejo variables
let var1="Maria";
//acceder al elemento p id mensaje_web
const men_elemento=document.getElementById("mensaje_web");
//asignar al elememto creado la variable
men_elemento.textContent=var1;
//condicionales
let mascota="Orion";
let salida;
if (mascota=="Orion"){
    salida="este perrito lo quiero mucho";
}//fin if
else{
    salida="ese perro no es mio :c"
}//fin else
//salida
document.getElementById("salida_web").textContent=salida;